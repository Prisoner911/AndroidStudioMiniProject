package com.example.campershaven;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class PlacesActivity2 extends AppCompatActivity {

    private LinearLayout placesContainer;
//    private TextView placeDesc;
    private SearchView searchView;
    ArrayList<Place> placesList = new ArrayList<>();
    private List<Place> filterList = new ArrayList<>();

    private static final String API_URL = "http://192.168.0.104/api/get_places.php"; // Replace with your actual API endpoint

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places2);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        searchView = findViewById(R.id.search_bar);
        placesContainer = findViewById(R.id.places_container);

        Toolbar toolbar = findViewById(R.id.menubar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.rectangle_1);
        toolbar.setNavigationOnClickListener(this::showPopupMenu);

        // Load places from the database
        new FetchPlacesTask().execute(API_URL);

        ImageView cartshop = findViewById(R.id.cartshop);
        cartshop.setOnClickListener(v -> {
            Intent intent = new Intent(PlacesActivity2.this, CartActivity.class);
            startActivity(intent);
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterPlace(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterPlace(newText);
                return false;
            }
        });
    }

    private void filterPlace(String query) {
        filterList.clear();
        for (Place place : placesList) { // Change from Product to Place
            if (place.getPlaceName().toLowerCase().contains(query.toLowerCase()) ||
                    place.getPlaceDescription().toLowerCase().contains(query.toLowerCase())) {
                filterList.add(place);
            }
        }
        displayProducts(filterList);
    }

    private void displayProducts(List<Place> places) {
        placesContainer.removeAllViews(); // Clear existing views
        for (Place place : places) {
            addPlaceToView(place);
        }
    }


    private class FetchPlacesTask extends AsyncTask<String, Void, ArrayList<Place>> {
        @Override
        protected ArrayList<Place> doInBackground(String... urls) {

            try {
                // Establish connection to the server
                URL url = new URL(urls[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                InputStream inputStream = conn.getInputStream();
                StringBuilder response = new StringBuilder();
                int data = inputStream.read();
                while (data != -1) {
                    response.append((char) data);
                    data = inputStream.read();
                }

                // Parse JSON response
                JSONArray jsonArray = new JSONArray(response.toString());
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    int srno = obj.getInt("srno");
                    String placeName = obj.getString("placename");
                    String placeDesc = obj.getString("placedescription");
                    String placeImgBase64 = obj.getString("placeimg");

                    // Decode image from Base64
                    byte[] decodedString = Base64.decode(placeImgBase64, Base64.DEFAULT);
                    Bitmap decodedImage = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                    placesList.add(new Place(srno, decodedImage, placeName, placeDesc));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return placesList;
        }

        @Override
        protected void onPostExecute(ArrayList<Place> places) {
            super.onPostExecute(places);
            for (Place place : places) {
                addPlaceToView(place);
            }
        }
    }


    private void addPlaceToView(Place place) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View cardView = inflater.inflate(R.layout.card_place, placesContainer, false);

        ImageView placeImage = cardView.findViewById(R.id.place_image);
        TextView placeName = cardView.findViewById(R.id.place_name);
        TextView placeDesc = cardView.findViewById(R.id.placeDescrition);
        LinearLayout cardLayout = cardView.findViewById(R.id.card_layout);

        placeImage.setImageBitmap(place.getPlaceImageData());
        placeName.setText(place.getPlaceName());
        placeDesc.setText(place.getPlaceDescription());


//        cardLayout.setOnClickListener(v -> {
//            Intent intent = new Intent(PlacesActivity2.this, Place_DetailsActivity.class);
//            intent.putExtra("PLACE_NAME", place.getPlaceName());
//            intent.putExtra("PLACE_DESCRIPTION", place.getPlaceDescription());
//
//            // Convert Bitmap to Base64 string
//            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//            place.getPlaceImageData().compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
//            String encodedImage = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);
//
//            intent.putExtra("PLACE_IMAGE", encodedImage); // Pass the Base64 string
//            startActivity(intent);
//        });

        placesContainer.addView(cardView);
    }

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });
        popupMenu.show();
    }

    private void handleHome() {
        startActivity(new Intent(this, MainActivity.class));
    }

    private void handleProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    private void handleLogout() {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(PlacesActivity2.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


}
