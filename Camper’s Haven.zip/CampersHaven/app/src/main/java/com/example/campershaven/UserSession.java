package com.example.campershaven;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class UserSession {
    private static UserSession instance;
    private String userId;
    private String username;

    private String email;

    private UserSession() {} // Private constructor

    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession(); // Create the instance if it does not exist
        }
        return instance; // Return the existing instance
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId; // Set the userId
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username; // Set the username
    }

    public void setEmail(String email){
        this.email = email;
    }

    public String getEmail(){
        return email;
    }

    public void clearSession() {
        userId = null;
        username = null;
        email = null;
    }
}

