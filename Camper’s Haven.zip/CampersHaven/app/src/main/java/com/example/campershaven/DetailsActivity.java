package com.example.campershaven;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.firebase.auth.FirebaseAuth;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;

public class DetailsActivity extends AppCompatActivity {
    private String selectedOption;
    private String nameInput;
    private String addressInput;
    private String phoneInput;
    private final OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_details);

        setupStatusBar();
        initializeFields();
        setupToolbar();
        setupContinueButton();
//        setupShoppingCartButton();
    }

    private void setupStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    private void initializeFields() {
        UserSession userSession = UserSession.getInstance();
        String userName = userSession.getUsername();

        RadioGroup radioGroup = findViewById(R.id.payment_method_group);
        EditText name = findViewById(R.id.name_input);
        EditText phone = findViewById(R.id.phone_input);
        EditText address = findViewById(R.id.address_input);

        name.setText(userName);

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton selectedRadioButton = findViewById(checkedId);
            selectedOption = selectedRadioButton != null ? selectedRadioButton.getText().toString() : null;
        });
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.barham);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon
        toolbar.setNavigationOnClickListener(this::showPopupMenu);
    }



    private void setupContinueButton() {
        ConstraintLayout continueBtn = findViewById(R.id.contBtn);
        continueBtn.setOnClickListener(v -> {
            // Retrieve values from EditText fields
            EditText name = findViewById(R.id.name_input);
            EditText phone = findViewById(R.id.phone_input);
            EditText address = findViewById(R.id.address_input);

            String nameInput = name.getText().toString().trim();
            String phoneInput = phone.getText().toString().trim();
            String addressInput = address.getText().toString().trim();

            // Validate input
            if (selectedOption == null) {
                Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show();
                return;
            }
            if (nameInput.isEmpty() || addressInput.isEmpty() || phoneInput.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            UserSession userSession = UserSession.getInstance();
            String userEmail = userSession.getEmail();
            String userId = userSession.getUserId();

            String url = "http://10.0.2.2/api/insertOrder.php"; // Update this URL as necessary

            FormBody requestBody = new FormBody.Builder()
                    .add("userId", userId)
                    .add("email", userEmail)
                    .add("name", nameInput)
                    .add("address", addressInput)
                    .add("phno", phoneInput)
                    .add("payment", selectedOption)
                    .add("paymentstatus", "complete")
                    .add("deliverystatus", "dispatching")
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build();

            client.newCall(request).enqueue(new okhttp3.Callback() {
                @Override
                public void onFailure(okhttp3.Call call, IOException e) {
                    Log.e("InsertCart", "Error during network request: " + e.getMessage());
                    runOnUiThread(() -> Toast.makeText(DetailsActivity.this, "Network request failed", Toast.LENGTH_SHORT).show());
                }

                @Override
                public void onResponse(okhttp3.Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d("InsertCart", "Product added to database successfully");
                        runOnUiThread(() -> Toast.makeText(DetailsActivity.this, "Product added to database", Toast.LENGTH_SHORT).show());
                    } else {
                        Log.e("InsertCart", "Failed to add to database: " + response.code());
                        runOnUiThread(() -> Toast.makeText(DetailsActivity.this, "Failed to add to database", Toast.LENGTH_SHORT).show());
                    }
                }
            });
        });
    }


    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.action_home) {
                startActivity(new Intent(DetailsActivity.this, MainActivity.class));
                return true;
            } else if (itemId == R.id.action_profile) {
                startActivity(new Intent(DetailsActivity.this, ProfileActivity.class));
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            }
            return false;
        });
        popupMenu.show();
    }

    private void handleLogout() {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(DetailsActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }



}
