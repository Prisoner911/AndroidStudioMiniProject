package com.example.campershaven;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CartActivity extends AppCompatActivity implements CartItemAdapter.OnRemoveClickListener {

    private Button button;

    private TextView totalAmount;
    private RecyclerView recyclerView;
    private CartItemAdapter cartItemAdapter;
    private List<CartItem> cartItems;

    private Button checkout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cart);

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        // Initialize RecyclerView and Adapter here
        recyclerView = findViewById(R.id.productRecyclerView);
        cartItems = new ArrayList<>();
        cartItemAdapter = new CartItemAdapter(this, cartItems, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(cartItemAdapter); // Set adapter after initializing recyclerView
        checkout = findViewById(R.id.checkout_button);
        totalAmount = findViewById(R.id.totalAmount);

        fetchCartItems(); // Fetch cart items from the server

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }


        // Setup toolbar and menu
        setupToolbar();

        ImageView cart = findViewById(R.id.cart);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CartActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });

        // Set an OnClickListener for the checkout button
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCheckout(); // Call the method to handle checkout
            }
        });


    }

    // Function to handle checkout action
    private void handleCheckout() {
        Intent intent = new Intent(CartActivity.this, DetailsActivity.class); // Replace with your actual CheckoutActivity
        startActivity(intent);
    }

    private void updateTotalPrice() {
        int total = 0; // Initialize total price
        for (CartItem item : cartItems) {
            try {
                // Parse price from String to int
                total += Integer.parseInt(item.getProductPrice()); // Assuming prices are in String format
            } catch (NumberFormatException e) {
                Log.e("CartActivity", "Error parsing price: " + e.getMessage());
            }
        }
        // Update the totalAmount TextView
        totalAmount.setText(String.valueOf(total) + " Rs");
    }


    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));
    }

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    private void handleHome() {
        startActivity(new Intent(CartActivity.this, MainActivity.class));
    }

    private void handleProfile() {
        startActivity(new Intent(CartActivity.this, ProfileActivity.class));
    }

    private void handleLogout() {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(CartActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void fetchCartItems() {
        UserSession userSession = UserSession.getInstance();
        String userId = userSession.getUserId();
        Log.d("userId", userId != null ? userId : "User ID is null");

        if (userId == null || userId.isEmpty()) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "http://192.168.0.104/api/get_cart_items.php?userId=" + userId;
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("CartActivity", "Error fetching cart items: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(CartActivity.this, "Failed to load cart", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String responseData = response.body().string();
                    Log.d("Response Data", responseData);

                    // Parse the response JSON
                    parseCartItems(responseData);
                } else {
                    runOnUiThread(() -> Toast.makeText(CartActivity.this, "Failed to load cart", Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    private void parseCartItems(String responseData) {
        try {
            JSONArray cartArray = new JSONArray(responseData);
            if (cartArray.length() == 0) {
                runOnUiThread(() -> Toast.makeText(CartActivity.this, "Your cart is empty", Toast.LENGTH_SHORT).show());
                return; // Early return if cart is empty
            }

            cartItems.clear(); // Clear the existing items
            for (int i = 0; i < cartArray.length(); i++) {
                JSONObject itemObj = cartArray.getJSONObject(i);
                CartItem cartItem = new CartItem();
                cartItem.setProductSr(itemObj.getInt("srno"));
                cartItem.setProductId(itemObj.getInt("pid"));
                cartItem.setProductName(itemObj.getString("pname"));
                cartItem.setProductPrice(itemObj.getString("pprice"));
                cartItem.setProductImageData(itemObj.getString("pimg"));
                cartItems.add(cartItem);
            }


            // Update UI on the main thread
            runOnUiThread(() -> {
                cartItemAdapter.notifyDataSetChanged();
                updateTotalPrice(); // Update total price after fetching items
            });
        } catch (JSONException e) {
            Log.e("CartActivity", "JSON parsing error: " + e.getMessage());
            runOnUiThread(() -> Toast.makeText(CartActivity.this, "Failed to parse cart data", Toast.LENGTH_SHORT).show());
        }
    }




    @Override
    public void onRemoveClick(int srNo) {
        // Remove the item from the cart using srNo
        removeItemFromCart(srNo);
        updateTotalPrice(); // Update total price after removal
    }

    private void removeItemFromCart(int srNo) {
        // Remove item locally
        for (CartItem item : cartItems) {
            if (item.getProductSr() == srNo) {
                cartItems.remove(item);
                cartItemAdapter.notifyDataSetChanged(); // Notify adapter about data change
                Toast.makeText(this, "Item removed from cart", Toast.LENGTH_SHORT).show();
                break;
            }
        }
        // Remove item from database
        removeItemFromDatabase(srNo);

    }

    private void removeItemFromDatabase(int srNo) {
        OkHttpClient client = new OkHttpClient();

        // Create the request body with the parameter
        RequestBody requestBody = new FormBody.Builder()
                .add("srNo", String.valueOf(srNo))
                .build();

        // Create the request
        Request request = new Request.Builder()
                .url("http://192.168.0.104/api/remove_cart_item.php") // Replace with your API URL
                .delete(requestBody) // Use DELETE method with body
                .build();

        // Execute the request asynchronously
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("RemoveItem", "Error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d("RemoveItem", "Item removed successfully");
                } else {
                    Log.e("RemoveItem", "Failed to remove item: " + response.code());
                }
            }
        });
    }
}
