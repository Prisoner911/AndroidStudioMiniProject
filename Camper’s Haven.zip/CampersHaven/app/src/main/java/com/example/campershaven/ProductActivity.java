package com.example.campershaven;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ProductActivity extends AppCompatActivity {

   private Button button;

    // Decode Base64 string to Bitmap
    private Bitmap decodeBase64ToBitmap(String base64Str) {
        byte[] decodedBytes = Base64.decode(base64Str, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        ImageView shop = findViewById(R.id.shop);
        shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });

       button = findViewById(R.id.add_to_cart_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(ProductActivity.this, CartActivity.class);
//                startActivity(intent);
                insertCart(getUserIdFromSharedPreferences(),productId);

            }
        });

        button = findViewById(R.id.buy_now_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductActivity.this, DetailsActivity.class);
                startActivity(intent);
            }
        });



        ImageView productImage = findViewById(R.id.product_image);
        TextView productName = findViewById(R.id.product_title);
        TextView productPrice = findViewById(R.id.price_info);
        TextView productDescription = findViewById(R.id.productDescription);

        // Get the product details passed from MainActivity
        // Retrieve product details from the Intent
        productId = getIntent().getIntExtra("productId", 0);
        String name = getIntent().getStringExtra("productName");
        String price = getIntent().getStringExtra("price");
        String imageData = getIntent().getStringExtra("imageData"); // Base64 image data
        String description = getIntent().getStringExtra("productDescription");



// Set product name and price
        productName.setText(name);
        productPrice.setText(price);
        productDescription.setText(description);

// Decode the Base64 string and set it as the image
        if (imageData != null) {
            Bitmap bitmap = decodeBase64ToBitmap(imageData);
            productImage.setImageBitmap(bitmap);
        }



        Toolbar toolbar = findViewById(R.id.tool);
        setSupportActionBar(toolbar);

        // Add a menu icon on the right side
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon

        // Set click listener for the icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));
    }

    private int productId; // Declare at class level
//    private String userId;

    // Method to retrieve userId from SharedPreferences
    private String getUserIdFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("YourSharedPrefName", MODE_PRIVATE);
        return sharedPreferences.getString("userId", null); // Return null if userId doesn't exist
    }

    private void insertCart(String userId, int productId) {
        if (userId == null) {
            Log.d("User ID", "User ID is null");
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "http://192.168.0.104/api/add_to_cart.php"; // Replace with your server URL

        // Use a separate thread to make network requests
        new Thread(() -> {
            try {
                // Create URL object
                URL requestUrl = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) requestUrl.openConnection();

                // Set up the connection
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Create request body
                String postData = "userId=" + URLEncoder.encode(userId, "UTF-8") +
                        "&productId=" + productId;

                // Send the request
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = postData.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Get the response
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    Log.d("InsertCart", "Product added to cart successfully");
                    runOnUiThread(() -> Toast.makeText(ProductActivity.this, "Product added to cart", Toast.LENGTH_SHORT).show());
                } else {
                    Log.e("InsertCart", "Failed to add product to cart: " + responseCode);
                    runOnUiThread(() -> Toast.makeText(ProductActivity.this, "Failed to add to cart", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                Log.e("InsertCart", "Error: " + e.getMessage());
            }
        }).start();
    }




    // Method to show PopupMenu
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });

        popupMenu.show();
    }

    private void  handleHome(){
        Intent intent = new Intent(ProductActivity.this, MainActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }
    // Profile handling
    private void handleProfile() {
        // Perform actions related to the profile, e.g., navigate to ProfileActivity
        Intent intent = new Intent(ProductActivity.this, ProfileActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }

    // Logout handling
    private void handleLogout() {
        FirebaseAuth.getInstance().signOut();
        // Perform logout actions, such as clearing user data or redirecting to login screen
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(ProductActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}

