package com.example.campershaven;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextEmail, editTextPassword, editTextRePassword;
    private Button buttonRegister;
    private TextView loginbtn;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance();

        // Link UI elements
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextRePassword = findViewById(R.id.editTextRePassword);
        buttonRegister = findViewById(R.id.buttonRegister);
        loginbtn = findViewById(R.id.loginbtn);

        // Underline the "Login" TextView
        SpannableString content = new SpannableString("Login");
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        loginbtn.setText(content);

        // Register button click listener
        buttonRegister.setOnClickListener(v -> registerUser());

        // Login TextView click listener
        loginbtn.setOnClickListener(v -> {
            // Redirect to the LoginActivity when "Login" is clicked
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Close the current activity
        });
    }

    private void registerUser() {
        String username = editTextUsername.getText().toString();
        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();
        String rePassword = editTextRePassword.getText().toString();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || rePassword.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(rePassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();

                        if (user != null) {
                            String userId = user.getUid();

                            // Save username to Realtime Database
                            FirebaseDatabase database = FirebaseDatabase.getInstance("https://campershaven-47c0a-default-rtdb.firebaseio.com/");
                            DatabaseReference databaseReference = database.getReference("users");

                            databaseReference.child(userId).child("username").setValue(username)
                                    .addOnCompleteListener(task1 -> {
                                        if (task1.isSuccessful()) {
                                            Log.d("Firebase", "Username saved successfully");


                                        } else {
                                            Log.e("Firebase", "Failed to save username: " + task1.getException());
                                        }
                                    });

                            databaseReference.child(userId).child("email").setValue(email)
                                    .addOnCompleteListener(task2 -> {
                                        if (task2.isSuccessful()) {
                                            Log.d("Firebase", "Email saved successfully");
                                            Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                            startActivity(intent);
                                        } else {
                                            Log.e("Firebase", "Failed to save email: " + task2.getException());
                                        }
                                    });



                        } else {
                            Log.e("Firebase", "User is null after registration.");
                        }
                    } else {
                        Log.e("Firebase", "Registration failed: " + task.getException());
                        // Handle registration failure
                        Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
