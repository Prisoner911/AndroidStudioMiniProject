package com.example.campershaven;


import android.graphics.Bitmap;

public class Place {

    private int srno;
    private Bitmap placeimg;       // Changed to match the JSON key
    private String placename;        // Changed to match the JSON key
    private String placedescription; // Changed to match the JSON key

    public Place(int srno, Bitmap placeimg, String placename, String placedescription) {
        this.srno = srno;
        this.placeimg = placeimg;
        this.placename = placename;
        this.placedescription = placedescription;


    }

    public int getPlaceSrno(){ return  srno; }

    public String getPlaceName() { return placename; } // Adjusted method
    public Bitmap getPlaceImageData() { return placeimg; } // Adjusted method
    public String getPlaceDescription() { return placedescription; } // Adjusted method
}
