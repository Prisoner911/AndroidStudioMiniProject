package com.example.campershaven;

public class Product {

    private int pid;
    private String pname;       // Changed to match the JSON key
    private String pimg;        // Changed to match the JSON key
    private String pdescription; // Changed to match the JSON key
    private int pprice;         // Changed to match the JSON key
    private int pstock;
    public Product(int pid, String pname, String pimg, String pdescription, int pprice ) {
        this.pid = pid;
        this.pname = pname;
        this.pprice = pprice;
        this.pimg = pimg;

        this.pdescription = pdescription;
    }

    public int getPid(){ return  pid; }

    public String getName() { return pname; } // Adjusted method
    public int getPrice() { return pprice; } // Adjusted method
    public String getImageData() { return pimg; } // Adjusted method
    public String getDescription() { return pdescription; } // Adjusted method
}
