package com.example.campershaven;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

public class ProfileActivity extends AppCompatActivity {
    private TextView username, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile); // Layout for the place details
        profileData();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }


        ImageView shoppycart = findViewById(R.id.shoppycart);
        shoppycart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });



        Toolbar toolbar = findViewById(R.id.barmenu);
        setSupportActionBar(toolbar);

        // Add a menu icon on the right side
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon

        // Set click listener for the icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));
    }


    public void profileData(){
        UserSession userSession = UserSession.getInstance();
        String userName = userSession.getUsername();
        String userEmail = userSession.getEmail();
        Log.d("userId", userName != null ? userName : "User ID is null");

        if (userName == null || userName.isEmpty() || userEmail == null || userEmail.isEmpty()) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        username = findViewById(R.id.userprofile);
        email = findViewById(R.id.useremail);

        username.setText(userName);
        email.setText(userEmail);


    }

    // Method to show PopupMenu
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });

        popupMenu.show();
    }

    private void handleHome() {
        Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
        startActivity(intent);
    }

    private void handleProfile() {
        Intent intent = new Intent(ProfileActivity.this, ProfileActivity.class);
        startActivity(intent);
    }

    private void handleLogout() {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    // Load image from Base64 string using Glide
    private void loadBase64Image(String encodedImage, ImageView imageView) {
        // Convert Base64 string to byte array
        byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
        // Convert byte array to Bitmap
        Bitmap decodedImage = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        // Load the Bitmap into the ImageView using Glide
        Glide.with(this)
                .load(decodedImage) // Load the Bitmap
                .into(imageView);
    }
}
