package com.example.campershaven;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campershaven.R;

import java.util.List;

public class CartItemAdapter extends RecyclerView.Adapter<CartItemAdapter.CartViewHolder> {

    private Context context;
    private List<CartItem> cartItems;
    private OnRemoveClickListener onRemoveClickListener; // Listener for removing items

    public CartItemAdapter(Context context, List<CartItem> cartItems, OnRemoveClickListener onRemoveClickListener) {
        this.context = context;
        this.cartItems = cartItems;
        this.onRemoveClickListener = onRemoveClickListener; // Assign the listener
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cart_item_layout, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);
        holder.productTitle.setText(item.getProductName());
        holder.productPrice.setText(item.getProductPrice() + " Rs");
        Bitmap bitmap = decodeBase64ToBitmap(item.getProductImageData());
        holder.productImage.setImageBitmap(bitmap);

        holder.buyNowButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailsActivity.class);
            context.startActivity(intent);
        });

        holder.removeButton.setOnClickListener(v -> {
            // Call the listener when the remove button is clicked
            if (onRemoveClickListener != null) {
                onRemoveClickListener.onRemoveClick(item.getProductSr());
            }
        });
    }

    private Bitmap decodeBase64ToBitmap(String base64Str) {
        byte[] decodedString = Base64.decode(base64Str, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        TextView productTitle, productPrice;
        Button buyNowButton, removeButton;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.product_image);
            productTitle = itemView.findViewById(R.id.product_title);
            productPrice = itemView.findViewById(R.id.product_price);
            buyNowButton = itemView.findViewById(R.id.buy_now_button);
            removeButton = itemView.findViewById(R.id.removebtn);

        }
    }

    public interface OnRemoveClickListener {
        void onRemoveClick(int srNo); // Callback for removing an item
    }
}
