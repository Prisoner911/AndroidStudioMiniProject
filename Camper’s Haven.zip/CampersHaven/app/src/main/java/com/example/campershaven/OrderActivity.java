package com.example.campershaven;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;

public class OrderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_order);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        ImageView shoppy = findViewById(R.id.shoppy);
        shoppy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OrderActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });

        Toolbar toolbar = findViewById(R.id.menu);
        setSupportActionBar(toolbar);

        // Add a menu icon on the right side
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon

        // Set click listener for the icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));
    }

    // Method to show PopupMenu
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });

        popupMenu.show();
    }

    private void  handleHome(){
        Intent intent = new Intent(OrderActivity.this, MainActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }
    // Profile handling
    private void handleProfile() {
        // Perform actions related to the profile, e.g., navigate to ProfileActivity
        Intent intent = new Intent(OrderActivity.this, ProfileActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }


    // Logout handling
    private void handleLogout() {
        FirebaseAuth.getInstance().signOut();
        // Perform logout actions, such as clearing user data or redirecting to login screen
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(OrderActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}