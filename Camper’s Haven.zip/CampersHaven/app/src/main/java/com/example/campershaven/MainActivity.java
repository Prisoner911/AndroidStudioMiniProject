package com.example.campershaven;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;



public class MainActivity extends AppCompatActivity {

    private LinearLayout containerLayout;
    private List<Product> productList;
    private List<Product> filteredList;
    private OkHttpClient client; // OkHttpClient instance
    private String userId;


    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }


        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();


// Get the currently signed-in user
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            String userId = currentUser.getUid(); // Fetch the user's ID

            DatabaseReference userRef = FirebaseDatabase
                    .getInstance("https://campershaven-47c0a-default-rtdb.firebaseio.com/")
                    .getReference("users")
                    .child(userId); // Reference to the current user's data

            // Fetch user data once
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // Directly access the user's data
                    String username = dataSnapshot.child("username").getValue(String.class);
                    String email = dataSnapshot.child("email").getValue(String.class);
                    Log.d("FirebaseData", "UserID: " + userId + ", Username: " + username + ", Email: " + email);

                    if (username != null && email != null) {
                        SharedPreferences sharedPreferences = getSharedPreferences("YourSharedPrefName", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        UserSession userSession = UserSession.getInstance();
                        userSession.setUserId(userId);
                        userSession.setUsername(username);
                        userSession.setEmail(email);

                        // Store user details in SharedPreferences
                        editor.putString("userId", userId);
                        editor.putString("username", username);
                        editor.putString("email", email);
                        editor.apply(); // Save changes

                        // Now send `userId` and `username` to your MySQL database.
                        sendUserToMySQL(userId, username);
                    } else {
                        Log.w("FirebaseData", "Username or Email is null");
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Handle potential errors here
                    Log.w("FirebaseData", "Database error: " + databaseError.getMessage());
                }
            });
        }


        // Initialize toolbar and set up menu icon
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));

        // Initialize UI components
        containerLayout = findViewById(R.id.containerLayout);


        SearchView searchView = findViewById(R.id.searchView);
        ConstraintLayout placebtn = findViewById(R.id.placebtn);
        ImageView shopCart = findViewById(R.id.shopCart);

        // Set up navigation button to PlacesActivity2
        placebtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PlacesActivity2.class);
            startActivity(intent);
        });

        // Set up navigation button to CartActivity
        shopCart.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CartActivity.class);
            startActivity(intent);
        });

        // Initialize product lists
        productList = new ArrayList<>();
        filteredList = new ArrayList<>();

        // Initialize OkHttpClient
        client = new OkHttpClient();

        // Fetch products from the database using OkHttp
        fetchProducts();

        // Set up search filter
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterProducts(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterProducts(newText);
                return false;
            }
        });
    }

    public void sendUserToMySQL(final String userId, final String username) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL("http://192.168.0.104/api/send_user_data.php");
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);

                    // Prepare the POST data
                    String postData = "userid=" + URLEncoder.encode(userId, "UTF-8") +
                            "&username=" + URLEncoder.encode(username, "UTF-8");

                    // Send the data to the server
                    try (OutputStream os = conn.getOutputStream();
                         BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"))) {
                        writer.write(postData);
                        writer.flush();
                    }

                    // Read the server response
                    int responseCode = conn.getResponseCode();
                    InputStream inputStream;
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        Log.d("MySQLInsert", "User inserted successfully");
                        inputStream = conn.getInputStream(); // Read response if needed
                    } else {
                        Log.e("MySQLInsert", "Failed to insert user, Response Code: " + responseCode);
                        inputStream = conn.getErrorStream(); // Get error stream if there is an error
                    }

                    // Read the response
                    StringBuilder responseBuilder = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            responseBuilder.append(line);
                        }
                    }
                    Log.d("MySQLInsertResponse", responseBuilder.toString());

                } catch (MalformedURLException e) {
                    Log.e("MySQLInsertError", "Malformed URL: " + e.getMessage());
                } catch (IOException e) {
                    Log.e("MySQLInsertError", "IO Exception: " + e.getMessage());
                } catch (Exception e) {
                    Log.e("MySQLInsertError", "General Exception: " + e.getMessage());
                } finally {
                    if (conn != null) {
                        conn.disconnect(); // Ensure connection is closed
                    }
                }
            }
        }).start();
    }



    // Show PopupMenu on toolbar icon click
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.action_home) {
                Toast.makeText(this, "Home clicked", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    // Decode Base64 image string to Bitmap
    private Bitmap decodeBase64ToBitmap(String base64Str) {
        byte[] decodedString = Base64.decode(base64Str, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }

    // Profile handling
    private void handleProfile() {
        Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
        startActivity(intent);
    }

    // Logout handling
    private void handleLogout() {
        // Sign out from Firebase
        FirebaseAuth.getInstance().signOut();


        // Clear any stored user session data
        UserSession.getInstance().clearSession();

        // Show logout message
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();

        // Navigate to LoginActivity and clear activity stack
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish(); // Close MainActivity
    }



    // Filter products based on search query
    private void filterProducts(String query) {
        filteredList.clear();
        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(query.toLowerCase()) ||
                    String.valueOf(product.getPrice()).contains(query)) {
                filteredList.add(product);
            }
        }
        displayProducts(filteredList);
    }

    // Display products in the UI
    private void displayProducts(List<Product> productsToShow) {
        containerLayout.removeAllViews();
        for (Product product : productsToShow) {
            View productCard = createProductCard(product);
            containerLayout.addView(productCard);
        }
    }

    // Create a product card view
// Create a product card view with click listener
    private View createProductCard(Product product) {
        View productCard = LayoutInflater.from(this).inflate(R.layout.product_card, containerLayout, false);
        ImageView imageView = productCard.findViewById(R.id.productImage);
        TextView nameView = productCard.findViewById(R.id.productName);
        TextView descriptionView = productCard.findViewById(R.id.productDescription);
        TextView priceView = productCard.findViewById(R.id.productPrice);

        // Decode Base64 image string to Bitmap and set to ImageView
        Bitmap bitmap = decodeBase64ToBitmap(product.getImageData());
        imageView.setImageBitmap(bitmap);

        nameView.setText(product.getName());
        descriptionView.setText(product.getDescription());
        priceView.setText(String.valueOf(product.getPrice()) + "Rs");

        Log.d("ProductData", "Name: " + product.getName() + ", Price: " + product.getPrice() + ", Description: " + product.getDescription() + ", ImageData: " + product.getImageData());


        // Set OnClickListener to open ProductActivity with product details
        productCard.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProductActivity.class);
            intent.putExtra("productId", product.getPid());
            intent.putExtra("productName", product.getName());
            intent.putExtra("price", String.valueOf(product.getPrice()) + " Rs");
            intent.putExtra("imageData", product.getImageData()); // Pass the Base64 string directly
            intent.putExtra("productDescription", product.getDescription());
            startActivity(intent);
        });

        return productCard;
    }




    // Fetch products from the database using OkHttp
    private void fetchProducts() {
        //make sure to add the ip in xml file
        String url = "http://192.168.0.104/api/get_data.php"; // Ensure this URL is correct

        Request request = new Request.Builder()
                .url(url)
                .build();

        Log.d("OkHttp Request", "URL: " + request.url());
        Log.d("OkHttp Request", "Headers: " + request.headers());

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("OkHttp Error", "Error: " + e.getMessage());
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Failed to fetch products", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String jsonResponse = response.body().string();
                    try {
                        JSONArray jsonArray = new JSONArray(jsonResponse);
                        productList.clear(); // Clear the existing product list
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject productJson = jsonArray.getJSONObject(i);
                            // Assuming your Product class has a constructor that accepts these parameters
                            int productId = productJson.getInt("pid");
                            String name = productJson.getString("pname");
                            String imageData = productJson.getString("pimg");
                            int price = productJson.getInt("pprice");
                            String description = productJson.getString("pdescription");

                            Product product = new Product(productId, name, imageData, description, price);
                            productList.add(product);
                        }
                        filteredList.clear();
                        filteredList.addAll(productList);
                        runOnUiThread(() -> displayProducts(filteredList));
                    } catch (JSONException e) {
                        Log.e("JSON Error", "Failed to parse JSON: " + e.getMessage());
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "Failed to parse products", Toast.LENGTH_SHORT).show();
                        });
                    }
                } else {
                    Log.e("OkHttp Error", "Unexpected code: " + response);
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Failed to fetch products", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }
}
