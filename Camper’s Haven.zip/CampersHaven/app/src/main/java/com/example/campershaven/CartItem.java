package com.example.campershaven;

public class CartItem {
    private int productId;
    private String productName;
    private String productPrice;
    private String productImageData;

    private  int productSr;

    private int total;

    // Getters and setters
    public int getProductId() { return productId; }

    public void setProductSr(int productSr) { this.productSr = productSr; }
    public int getProductSr() { return productSr; }
    public void setProductId(int productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public String getProductPrice() { return productPrice; }
    public void setProductPrice(String productPrice) { this.productPrice = productPrice; }

    public String getProductImageData() { return productImageData; }
    public void setProductImageData(String productImageData) { this.productImageData = productImageData; }

    public void setTotal(int total){this.total = total;}
    public int getTotal(){return total;}


}

